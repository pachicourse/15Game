package minigame;

import java.awt.event.*;
import java.awt.*;
import java.awt.image.*;

public class GameController implements Runnable, KeyListener {
	Actor PlayerCharacter;
	int endPosX = 9, endPosY = 9;
	public GameController() {
		new Stage();
		Stage.stage.frame.addKeyListener(this);
		Stage.stage.frame.setVisible(true);
		(new Thread(this)).start();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		synchronized(Actor.actors) {
			//赤い丸(Actor)
			Image image = new BufferedImage(Game.TILESIZE, Game.TILESIZE, BufferedImage.TYPE_INT_ARGB);
			Graphics graphics = image.getGraphics();
			graphics.setColor(Color.RED);
			graphics.fillOval(2, 2, 28, 28);
			new Actor(image, 2, 3, true, true);
			
			//緑の四角形(Character)
			image = new BufferedImage(Game.TILESIZE, Game.TILESIZE, BufferedImage.TYPE_INT_ARGB);
			graphics = image.getGraphics();
			graphics.setColor(Color.GREEN);
			graphics.fillRect(4, 4, 25, 25);
			new Character(image, 3, 5, 1000);
			
			//プレイヤーキャラ
			image = new BufferedImage(Game.TILESIZE, Game.TILESIZE, BufferedImage.TYPE_INT_ARGB);
			graphics = image.getGraphics();
			graphics.setColor(Color.BLUE);
			graphics.fillPolygon(new int[] {16, 1, 30}, new int[] {4, 28, 28}, 3);
			this.PlayerCharacter = new Actor(image, 5, 2);
			
		}
		Stage.stage.repaint();
		
		synchronized(this) {
			while(!this.gameIsOver()) {
				try {
					this.wait();
				} catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		Stage.stage.frame.removeKeyListener(this);
	}
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub
		int x = 0; int y = 0;
		switch(arg0.getKeyCode()) {
		case KeyEvent.VK_UP:
			y--;
			break;
		case KeyEvent.VK_DOWN:
			y++;
			break;
		case KeyEvent.VK_RIGHT:
			x++;
			break;
		case KeyEvent.VK_LEFT:
			x--;
			break;
		}
		Actor a = Actor.existsAt(PlayerCharacter.posX + x, PlayerCharacter.posY + y);
		if(a == null) {
			if(!Actor.tileOut(PlayerCharacter.posX + x, PlayerCharacter.posY + y)) {
				if(Actor.frameOut(PlayerCharacter.posX + x, PlayerCharacter.posY + y)) {
					Stage.baseX -= x;
					Stage.baseY -= y;
				}
				PlayerCharacter.posX += x;
				PlayerCharacter.posY += y;
			}
		} else if(a.isEdible){
			a.eaten();
			PlayerCharacter.posX += x;
			PlayerCharacter.posY += y;
		} else {
			a.pushed(x, y);
		}
		synchronized(this) {
			this.notify();
		}
		Stage.stage.repaint();
	}
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	public boolean gameIsOver() {
		if(PlayerCharacter.posX == endPosX && PlayerCharacter.posY == endPosY) {
			System.out.println("true");
			return true;
		}
		return false;
	}

}
